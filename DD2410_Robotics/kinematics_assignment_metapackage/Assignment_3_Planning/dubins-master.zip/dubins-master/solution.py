#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# {student full name}
# {student id}
# {student email}


def solution(car):

    ''' <<< write your code below >>> '''
    controls=[0]
    times=[0,1]

    ''' <<< write your code below >>> '''

    return controls, times
